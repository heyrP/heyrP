module.exports = {
  productionSourceMap: false
};