export default {
	delay: time => new Promise(resolve => setTimeout(resolve, time)),
}